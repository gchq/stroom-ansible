-- MySQL dump 10.13  Distrib 5.6.43, for Linux (x86_64)
--
-- Host: localhost    Database: stroom
-- ------------------------------------------------------
-- Server version	5.6.43

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ACTIVITY`
--

DROP TABLE IF EXISTS `ACTIVITY`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ACTIVITY` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `VER` tinyint(4) NOT NULL,
  `CRT_MS` bigint(20) DEFAULT NULL,
  `CRT_USER` varchar(255) DEFAULT NULL,
  `UPD_MS` bigint(20) DEFAULT NULL,
  `UPD_USER` varchar(255) DEFAULT NULL,
  `USER_ID` varchar(255) NOT NULL,
  `JSON` longtext,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ACTIVITY`
--

LOCK TABLES `ACTIVITY` WRITE;
/*!40000 ALTER TABLE `ACTIVITY` DISABLE KEYS */;
/*!40000 ALTER TABLE `ACTIVITY` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `APP_PERM`
--

DROP TABLE IF EXISTS `APP_PERM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `APP_PERM` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `VER` tinyint(4) NOT NULL,
  `USR_UUID` varchar(255) NOT NULL,
  `FK_PERM_ID` int(11) NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `APP_PERM_USR_UUID_FK_PERM_ID_IDX` (`USR_UUID`,`FK_PERM_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `APP_PERM`
--

LOCK TABLES `APP_PERM` WRITE;
/*!40000 ALTER TABLE `APP_PERM` DISABLE KEYS */;
INSERT INTO `APP_PERM` VALUES (1,1,'2d6b03f6-7108-417d-9daf-4f8bbcf3f5b5',1);
/*!40000 ALTER TABLE `APP_PERM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CLSTR_LK`
--

DROP TABLE IF EXISTS `CLSTR_LK`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CLSTR_LK` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `VER` tinyint(4) NOT NULL,
  `NAME` varchar(255) NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `NAME` (`NAME`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CLSTR_LK`
--

LOCK TABLES `CLSTR_LK` WRITE;
/*!40000 ALTER TABLE `CLSTR_LK` DISABLE KEYS */;
INSERT INTO `CLSTR_LK` VALUES (1,0,'UserAppPermissionService'),(2,0,'JobNodeService'),(3,0,'StreamTaskCreator');
/*!40000 ALTER TABLE `CLSTR_LK` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DASH`
--

DROP TABLE IF EXISTS `DASH`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DASH` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `VER` tinyint(4) NOT NULL,
  `CRT_MS` bigint(20) DEFAULT NULL,
  `CRT_USER` varchar(255) DEFAULT NULL,
  `UPD_MS` bigint(20) DEFAULT NULL,
  `UPD_USER` varchar(255) DEFAULT NULL,
  `NAME` varchar(255) NOT NULL,
  `UUID` varchar(255) DEFAULT NULL,
  `DAT` longtext,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `UUID` (`UUID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DASH`
--

LOCK TABLES `DASH` WRITE;
/*!40000 ALTER TABLE `DASH` DISABLE KEYS */;
/*!40000 ALTER TABLE `DASH` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DICT`
--

DROP TABLE IF EXISTS `DICT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DICT` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `VER` tinyint(4) NOT NULL,
  `CRT_MS` bigint(20) DEFAULT NULL,
  `CRT_USER` varchar(255) DEFAULT NULL,
  `UPD_MS` bigint(20) DEFAULT NULL,
  `UPD_USER` varchar(255) DEFAULT NULL,
  `NAME` varchar(255) NOT NULL,
  `UUID` varchar(255) DEFAULT NULL,
  `DAT` longtext,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `UUID` (`UUID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DICT`
--

LOCK TABLES `DICT` WRITE;
/*!40000 ALTER TABLE `DICT` DISABLE KEYS */;
/*!40000 ALTER TABLE `DICT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DOC_PERM`
--

DROP TABLE IF EXISTS `DOC_PERM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DOC_PERM` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `VER` tinyint(4) NOT NULL,
  `USR_UUID` varchar(255) NOT NULL,
  `DOC_TP` varchar(255) NOT NULL,
  `DOC_UUID` varchar(255) NOT NULL,
  `PERM` varchar(255) NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `DOC_PERM_USR_UUID_DOC_TP_DOC_UUID_PERM_IDX` (`USR_UUID`,`DOC_TP`,`DOC_UUID`,`PERM`),
  KEY `DOC_PERM_DOC_TP_DOC_UUID` (`DOC_TP`,`DOC_UUID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DOC_PERM`
--

LOCK TABLES `DOC_PERM` WRITE;
/*!40000 ALTER TABLE `DOC_PERM` DISABLE KEYS */;
/*!40000 ALTER TABLE `DOC_PERM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FD`
--

DROP TABLE IF EXISTS `FD`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `FD` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `VER` tinyint(4) NOT NULL,
  `CRT_USER` varchar(255) DEFAULT NULL,
  `UPD_USER` varchar(255) DEFAULT NULL,
  `NAME` varchar(255) NOT NULL,
  `DESCRIP` longtext,
  `STAT` tinyint(4) NOT NULL,
  `CLS` varchar(255) DEFAULT NULL,
  `CTX_ENC` varchar(255) DEFAULT NULL,
  `ENC` varchar(255) DEFAULT NULL,
  `REF` bit(1) NOT NULL,
  `RETEN_DAY_AGE` int(11) DEFAULT NULL,
  `FK_STRM_TP_ID` int(11) NOT NULL,
  `CRT_MS` bigint(20) DEFAULT NULL,
  `UPD_MS` bigint(20) DEFAULT NULL,
  `UUID` varchar(255) NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `NAME` (`NAME`),
  UNIQUE KEY `UUID` (`UUID`),
  KEY `FD_FK_STRM_TP_ID` (`FK_STRM_TP_ID`),
  CONSTRAINT `FD_FK_STRM_TP_ID` FOREIGN KEY (`FK_STRM_TP_ID`) REFERENCES `STRM_TP` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FD`
--

LOCK TABLES `FD` WRITE;
/*!40000 ALTER TABLE `FD` DISABLE KEYS */;
/*!40000 ALTER TABLE `FD` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GLOB_PROP`
--

DROP TABLE IF EXISTS `GLOB_PROP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `GLOB_PROP` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `VER` tinyint(4) NOT NULL,
  `CRT_MS` bigint(20) DEFAULT NULL,
  `CRT_USER` varchar(255) DEFAULT NULL,
  `UPD_MS` bigint(20) DEFAULT NULL,
  `UPD_USER` varchar(255) DEFAULT NULL,
  `NAME` varchar(255) NOT NULL,
  `VAL` longtext NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `NAME` (`NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GLOB_PROP`
--

LOCK TABLES `GLOB_PROP` WRITE;
/*!40000 ALTER TABLE `GLOB_PROP` DISABLE KEYS */;
/*!40000 ALTER TABLE `GLOB_PROP` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `IDX`
--

DROP TABLE IF EXISTS `IDX`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `IDX` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `VER` tinyint(4) NOT NULL,
  `CRT_USER` varchar(255) DEFAULT NULL,
  `UPD_USER` varchar(255) DEFAULT NULL,
  `NAME` varchar(255) NOT NULL,
  `DESCRIP` longtext,
  `MAX_DOC` int(11) NOT NULL,
  `MAX_SHRD` int(11) NOT NULL,
  `PART_BY` tinyint(4) DEFAULT NULL,
  `PART_SZ` int(11) NOT NULL,
  `RETEN_DAY_AGE` int(11) DEFAULT NULL,
  `FLDS` longtext,
  `CRT_MS` bigint(20) DEFAULT NULL,
  `UPD_MS` bigint(20) DEFAULT NULL,
  `UUID` varchar(255) NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `UUID` (`UUID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `IDX`
--

LOCK TABLES `IDX` WRITE;
/*!40000 ALTER TABLE `IDX` DISABLE KEYS */;
/*!40000 ALTER TABLE `IDX` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `IDX_SHRD`
--

DROP TABLE IF EXISTS `IDX_SHRD`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `IDX_SHRD` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `VER` tinyint(4) NOT NULL,
  `CRT_USER` varchar(255) DEFAULT NULL,
  `UPD_USER` varchar(255) DEFAULT NULL,
  `CMT_DOC_CT` int(11) DEFAULT NULL,
  `CMT_DUR_MS` bigint(20) DEFAULT NULL,
  `CMT_MS` bigint(20) DEFAULT NULL,
  `DOC_CT` int(11) NOT NULL,
  `FILE_SZ` bigint(20) DEFAULT NULL,
  `STAT` tinyint(4) NOT NULL,
  `FK_IDX_ID` int(11) NOT NULL,
  `FK_ND_ID` int(11) NOT NULL,
  `PART` varchar(255) NOT NULL,
  `FK_VOL_ID` int(11) NOT NULL,
  `IDX_VER` varchar(255) DEFAULT NULL,
  `CRT_MS` bigint(20) DEFAULT NULL,
  `UPD_MS` bigint(20) DEFAULT NULL,
  `PART_FROM_MS` bigint(20) DEFAULT NULL,
  `PART_TO_MS` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IDX_SHRD_FK_VOL_ID` (`FK_VOL_ID`),
  KEY `IDX_SHRD_FK_IDX_ID` (`FK_IDX_ID`),
  KEY `IDX_SHRD_FK_ND_ID` (`FK_ND_ID`),
  CONSTRAINT `IDX_SHRD_FK_IDX_ID` FOREIGN KEY (`FK_IDX_ID`) REFERENCES `IDX` (`ID`),
  CONSTRAINT `IDX_SHRD_FK_ND_ID` FOREIGN KEY (`FK_ND_ID`) REFERENCES `ND` (`ID`),
  CONSTRAINT `IDX_SHRD_FK_VOL_ID` FOREIGN KEY (`FK_VOL_ID`) REFERENCES `VOL` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `IDX_SHRD`
--

LOCK TABLES `IDX_SHRD` WRITE;
/*!40000 ALTER TABLE `IDX_SHRD` DISABLE KEYS */;
/*!40000 ALTER TABLE `IDX_SHRD` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `IDX_VOL`
--

DROP TABLE IF EXISTS `IDX_VOL`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `IDX_VOL` (
  `FK_IDX_ID` int(11) NOT NULL,
  `FK_VOL_ID` int(11) NOT NULL,
  PRIMARY KEY (`FK_IDX_ID`,`FK_VOL_ID`),
  KEY `IDX_FK_VOL_ID` (`FK_VOL_ID`),
  CONSTRAINT `IDX_FK_VOL_ID` FOREIGN KEY (`FK_VOL_ID`) REFERENCES `VOL` (`ID`),
  CONSTRAINT `VOL_FK_IDX_ID` FOREIGN KEY (`FK_IDX_ID`) REFERENCES `IDX` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `IDX_VOL`
--

LOCK TABLES `IDX_VOL` WRITE;
/*!40000 ALTER TABLE `IDX_VOL` DISABLE KEYS */;
/*!40000 ALTER TABLE `IDX_VOL` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `JB`
--

DROP TABLE IF EXISTS `JB`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `JB` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `VER` tinyint(4) NOT NULL,
  `CRT_USER` varchar(255) DEFAULT NULL,
  `UPD_USER` varchar(255) DEFAULT NULL,
  `NAME` varchar(255) NOT NULL,
  `ENBL` bit(1) NOT NULL,
  `CRT_MS` bigint(20) DEFAULT NULL,
  `UPD_MS` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `NAME` (`NAME`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `JB`
--

LOCK TABLES `JB` WRITE;
/*!40000 ALTER TABLE `JB` DISABLE KEYS */;
INSERT INTO `JB` VALUES (1,0,'INTERNAL','INTERNAL','Property Cache Reload','',1577451711460,1577451711460),(2,0,'INTERNAL','INTERNAL','Java Heap Histogram Statistics','\0',1577451711464,1577451711464),(3,0,'INTERNAL','INTERNAL','Node Status','',1577451711475,1577451711475),(4,0,'INTERNAL','INTERNAL','Pipeline Destination Roll','',1577451711486,1577451711486),(5,0,'INTERNAL','INTERNAL','Data Retention','',1577451711494,1577451711494),(6,0,'INTERNAL','INTERNAL','Stream Attributes Retention','',1577451711502,1577451711502),(7,0,'INTERNAL','INTERNAL','Stream Retention','',1577451711506,1577451711506),(8,0,'INTERNAL','INTERNAL','Stream Delete','',1577451711511,1577451711511),(9,0,'INTERNAL','INTERNAL','File System Clean','',1577451711516,1577451711516),(10,0,'INTERNAL','INTERNAL','Stream Task Queue Statistics','',1577451711521,1577451711521),(11,0,'INTERNAL','INTERNAL','Proxy Aggregation','',1577451711528,1577451711528),(12,0,'INTERNAL','INTERNAL','Stream Task Retention','',1577451711534,1577451711534),(13,0,'INTERNAL','INTERNAL','Volume Status','',1577451711538,1577451711538),(14,0,'INTERNAL','INTERNAL','XX Benchmark System XX','\0',1577451711543,1577451711543),(15,0,'INTERNAL','INTERNAL','Index Shard Delete','',1577451711548,1577451711548),(16,0,'INTERNAL','INTERNAL','Index Shard Retention','',1577451711552,1577451711552),(17,0,'INTERNAL','INTERNAL','Index Writer Cache Sweep','',1577451711557,1577451711557),(18,0,'INTERNAL','INTERNAL','Index Writer Flush','',1577451711562,1577451711562),(19,0,'INTERNAL','INTERNAL','Query History Clean','',1577451711565,1577451711565),(20,0,'INTERNAL','INTERNAL','SQL Stats Database Aggregation','',1577451711572,1577451711572),(21,0,'INTERNAL','INTERNAL','SQL Stats In Memory Flush','',1577451711577,1577451711577),(22,0,'INTERNAL','INTERNAL','Stream Processor','\0',1577451711588,1577451711588);
/*!40000 ALTER TABLE `JB` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `JB_ND`
--

DROP TABLE IF EXISTS `JB_ND`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `JB_ND` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `VER` tinyint(4) NOT NULL,
  `CRT_USER` varchar(255) DEFAULT NULL,
  `UPD_USER` varchar(255) DEFAULT NULL,
  `JB_TP` tinyint(4) NOT NULL,
  `ENBL` bit(1) NOT NULL,
  `SCHEDULE` varchar(255) DEFAULT NULL,
  `TASK_LMT` int(11) NOT NULL,
  `FK_JB_ID` int(11) NOT NULL,
  `FK_ND_ID` int(11) NOT NULL,
  `CRT_MS` bigint(20) DEFAULT NULL,
  `UPD_MS` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `FK_ND_ID` (`FK_ND_ID`,`FK_JB_ID`),
  KEY `JB_ND_FK_JB_ID` (`FK_JB_ID`),
  CONSTRAINT `JB_ND_FK_JB_ID` FOREIGN KEY (`FK_JB_ID`) REFERENCES `JB` (`ID`),
  CONSTRAINT `JB_ND_FK_ND_ID` FOREIGN KEY (`FK_ND_ID`) REFERENCES `ND` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `JB_ND`
--

LOCK TABLES `JB_ND` WRITE;
/*!40000 ALTER TABLE `JB_ND` DISABLE KEYS */;
INSERT INTO `JB_ND` VALUES (1,0,'INTERNAL','INTERNAL',2,'','1m',20,1,1,1577451711462,1577451711462),(2,0,'INTERNAL','INTERNAL',1,'\0','0 * *',20,2,1,1577451711466,1577451711466),(3,0,'INTERNAL','INTERNAL',1,'','* * *',20,3,1,1577451711476,1577451711476),(4,0,'INTERNAL','INTERNAL',2,'','1m',20,4,1,1577451711489,1577451711489),(5,0,'INTERNAL','INTERNAL',1,'','0 0 *',20,5,1,1577451711496,1577451711496),(6,0,'INTERNAL','INTERNAL',2,'','1d',20,6,1,1577451711504,1577451711504),(7,0,'INTERNAL','INTERNAL',1,'','0 0 *',20,7,1,1577451711507,1577451711507),(8,0,'INTERNAL','INTERNAL',1,'','0 0 *',20,8,1,1577451711513,1577451711513),(9,0,'INTERNAL','INTERNAL',1,'','0 0 *',20,9,1,1577451711518,1577451711518),(10,0,'INTERNAL','INTERNAL',2,'','1m',20,10,1,1577451711523,1577451711523),(11,0,'INTERNAL','INTERNAL',1,'','0,10,20,30,40,50 * *',20,11,1,1577451711530,1577451711530),(12,0,'INTERNAL','INTERNAL',2,'','1d',20,12,1,1577451711536,1577451711536),(13,0,'INTERNAL','INTERNAL',2,'','5m',20,13,1,1577451711540,1577451711540),(14,0,'INTERNAL','INTERNAL',1,'\0','* * *',20,14,1,1577451711545,1577451711545),(15,0,'INTERNAL','INTERNAL',1,'','0 0 *',20,15,1,1577451711549,1577451711549),(16,0,'INTERNAL','INTERNAL',2,'','10m',20,16,1,1577451711554,1577451711554),(17,0,'INTERNAL','INTERNAL',2,'','10m',20,17,1,1577451711559,1577451711559),(18,0,'INTERNAL','INTERNAL',2,'','10m',20,18,1,1577451711563,1577451711563),(19,0,'INTERNAL','INTERNAL',1,'','0 0 *',20,19,1,1577451711568,1577451711568),(20,0,'INTERNAL','INTERNAL',1,'','5,15,25,35,45,55 * *',20,20,1,1577451711575,1577451711575),(21,0,'INTERNAL','INTERNAL',1,'','0,10,20,30,40,50 * *',20,21,1,1577451711579,1577451711579),(22,0,'INTERNAL','INTERNAL',3,'\0',NULL,20,22,1,1577451711590,1577451711590);
/*!40000 ALTER TABLE `JB_ND` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ND`
--

DROP TABLE IF EXISTS `ND`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ND` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `VER` tinyint(4) NOT NULL,
  `CRT_USER` varchar(255) DEFAULT NULL,
  `UPD_USER` varchar(255) DEFAULT NULL,
  `CLSTR_URL` varchar(255) DEFAULT NULL,
  `NAME` varchar(255) NOT NULL,
  `PRIOR` smallint(6) NOT NULL,
  `ENBL` bit(1) NOT NULL,
  `FK_RK_ID` int(11) NOT NULL,
  `CRT_MS` bigint(20) DEFAULT NULL,
  `UPD_MS` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `NAME` (`NAME`),
  KEY `ND_FK_RK_ID` (`FK_RK_ID`),
  CONSTRAINT `ND_FK_RK_ID` FOREIGN KEY (`FK_RK_ID`) REFERENCES `RK` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ND`
--

LOCK TABLES `ND` WRITE;
/*!40000 ALTER TABLE `ND` DISABLE KEYS */;
INSERT INTO `ND` VALUES (1,0,'INTERNAL','INTERNAL',NULL,'node1a',1,'',1,1577451711380,1577451711380);
/*!40000 ALTER TABLE `ND` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PERM`
--

DROP TABLE IF EXISTS `PERM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PERM` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `VER` tinyint(4) NOT NULL,
  `NAME` varchar(255) NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `NAME` (`NAME`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PERM`
--

LOCK TABLES `PERM` WRITE;
/*!40000 ALTER TABLE `PERM` DISABLE KEYS */;
INSERT INTO `PERM` VALUES (1,1,'Administrator'),(2,0,'Import Configuration'),(3,0,'Download Search Results'),(4,0,'Manage Policies'),(5,0,'Manage Jobs'),(6,0,'Export Configuration'),(7,0,'Data - View'),(8,0,'Manage Volumes'),(9,0,'Data - Import'),(10,0,'Manage Users'),(11,0,'Manage Nodes'),(12,0,'Manage DB'),(13,0,'Manage Processors'),(14,0,'Manage Index Shards'),(15,0,'Data - Delete'),(16,0,'Data - Export'),(17,0,'Pipeline Stepping'),(18,0,'Manage Tasks'),(19,0,'Data - View With Pipeline'),(20,0,'Manage Cache'),(21,0,'Manage Properties');
/*!40000 ALTER TABLE `PERM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PIPE`
--

DROP TABLE IF EXISTS `PIPE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PIPE` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `VER` tinyint(4) NOT NULL,
  `CRT_MS` bigint(20) DEFAULT NULL,
  `CRT_USER` varchar(255) DEFAULT NULL,
  `UPD_MS` bigint(20) DEFAULT NULL,
  `UPD_USER` varchar(255) DEFAULT NULL,
  `NAME` varchar(255) NOT NULL,
  `UUID` varchar(255) NOT NULL,
  `DESCRIP` longtext,
  `PARNT_PIPE` longtext,
  `DAT` longtext,
  `PIPE_TP` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `UUID` (`UUID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PIPE`
--

LOCK TABLES `PIPE` WRITE;
/*!40000 ALTER TABLE `PIPE` DISABLE KEYS */;
/*!40000 ALTER TABLE `PIPE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `POLICY`
--

DROP TABLE IF EXISTS `POLICY`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `POLICY` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `VER` tinyint(4) NOT NULL,
  `CRT_MS` bigint(20) DEFAULT NULL,
  `CRT_USER` varchar(255) DEFAULT NULL,
  `UPD_MS` bigint(20) DEFAULT NULL,
  `UPD_USER` varchar(255) DEFAULT NULL,
  `NAME` varchar(255) NOT NULL,
  `DAT` longtext,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `NAME` (`NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `POLICY`
--

LOCK TABLES `POLICY` WRITE;
/*!40000 ALTER TABLE `POLICY` DISABLE KEYS */;
/*!40000 ALTER TABLE `POLICY` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `QUERY`
--

DROP TABLE IF EXISTS `QUERY`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `QUERY` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `VER` tinyint(4) NOT NULL,
  `CRT_MS` bigint(20) DEFAULT NULL,
  `CRT_USER` varchar(255) DEFAULT NULL,
  `UPD_MS` bigint(20) DEFAULT NULL,
  `UPD_USER` varchar(255) DEFAULT NULL,
  `NAME` varchar(255) DEFAULT NULL,
  `UUID` varchar(255) DEFAULT NULL,
  `DASH_ID` bigint(20) DEFAULT NULL,
  `DAT` longtext,
  `FAVOURITE` bit(1) NOT NULL,
  `FK_FOLDER_ID` int(11) DEFAULT NULL,
  `QUERY_ID` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `UUID` (`UUID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QUERY`
--

LOCK TABLES `QUERY` WRITE;
/*!40000 ALTER TABLE `QUERY` DISABLE KEYS */;
/*!40000 ALTER TABLE `QUERY` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `RK`
--

DROP TABLE IF EXISTS `RK`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `RK` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `VER` tinyint(4) NOT NULL,
  `CRT_USER` varchar(255) DEFAULT NULL,
  `UPD_USER` varchar(255) DEFAULT NULL,
  `NAME` varchar(255) NOT NULL,
  `CRT_MS` bigint(20) DEFAULT NULL,
  `UPD_MS` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `NAME` (`NAME`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `RK`
--

LOCK TABLES `RK` WRITE;
/*!40000 ALTER TABLE `RK` DISABLE KEYS */;
INSERT INTO `RK` VALUES (1,0,'INTERNAL','INTERNAL','rack',1577451711377,1577451711377);
/*!40000 ALTER TABLE `RK` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SCRIPT`
--

DROP TABLE IF EXISTS `SCRIPT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SCRIPT` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `VER` tinyint(4) NOT NULL,
  `CRT_MS` bigint(20) DEFAULT NULL,
  `CRT_USER` varchar(255) DEFAULT NULL,
  `UPD_MS` bigint(20) DEFAULT NULL,
  `UPD_USER` varchar(255) DEFAULT NULL,
  `NAME` varchar(255) NOT NULL,
  `UUID` varchar(255) DEFAULT NULL,
  `DESCRIP` longtext,
  `DEP` longtext,
  `DAT` longtext,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `UUID` (`UUID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SCRIPT`
--

LOCK TABLES `SCRIPT` WRITE;
/*!40000 ALTER TABLE `SCRIPT` DISABLE KEYS */;
/*!40000 ALTER TABLE `SCRIPT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SQL_STAT_KEY`
--

DROP TABLE IF EXISTS `SQL_STAT_KEY`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SQL_STAT_KEY` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `VER` tinyint(4) NOT NULL,
  `NAME` varchar(766) NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `NAME` (`NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SQL_STAT_KEY`
--

LOCK TABLES `SQL_STAT_KEY` WRITE;
/*!40000 ALTER TABLE `SQL_STAT_KEY` DISABLE KEYS */;
/*!40000 ALTER TABLE `SQL_STAT_KEY` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SQL_STAT_VAL`
--

DROP TABLE IF EXISTS `SQL_STAT_VAL`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SQL_STAT_VAL` (
  `TIME_MS` bigint(20) NOT NULL,
  `PRES` tinyint(4) NOT NULL,
  `VAL_TP` tinyint(4) NOT NULL,
  `VAL` bigint(20) NOT NULL,
  `CT` bigint(20) NOT NULL,
  `FK_SQL_STAT_KEY_ID` bigint(20) NOT NULL,
  PRIMARY KEY (`FK_SQL_STAT_KEY_ID`,`TIME_MS`,`VAL_TP`,`PRES`),
  KEY `SQL_STAT_VAL_TIME_MS` (`TIME_MS`),
  CONSTRAINT `SQL_STAT_VAL_FK_STAT_KEY_ID` FOREIGN KEY (`FK_SQL_STAT_KEY_ID`) REFERENCES `SQL_STAT_KEY` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SQL_STAT_VAL`
--

LOCK TABLES `SQL_STAT_VAL` WRITE;
/*!40000 ALTER TABLE `SQL_STAT_VAL` DISABLE KEYS */;
/*!40000 ALTER TABLE `SQL_STAT_VAL` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SQL_STAT_VAL_SRC`
--

DROP TABLE IF EXISTS `SQL_STAT_VAL_SRC`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SQL_STAT_VAL_SRC` (
  `TIME_MS` bigint(20) NOT NULL,
  `NAME` varchar(766) NOT NULL,
  `VAL_TP` tinyint(4) NOT NULL,
  `VAL` bigint(20) NOT NULL,
  `PROCESSING` bit(1) NOT NULL DEFAULT b'0',
  KEY `SQL_STAT_VAL_SRC_PROCESSING_TIME_MS` (`PROCESSING`,`TIME_MS`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SQL_STAT_VAL_SRC`
--

LOCK TABLES `SQL_STAT_VAL_SRC` WRITE;
/*!40000 ALTER TABLE `SQL_STAT_VAL_SRC` DISABLE KEYS */;
/*!40000 ALTER TABLE `SQL_STAT_VAL_SRC` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `STATE_DAT_SRC`
--

DROP TABLE IF EXISTS `STATE_DAT_SRC`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `STATE_DAT_SRC` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `VER` tinyint(4) NOT NULL,
  `CRT_MS` bigint(20) DEFAULT NULL,
  `CRT_USER` varchar(255) DEFAULT NULL,
  `UPD_MS` bigint(20) DEFAULT NULL,
  `UPD_USER` varchar(255) DEFAULT NULL,
  `NAME` varchar(255) NOT NULL,
  `UUID` varchar(255) DEFAULT NULL,
  `DESCRIP` longtext,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `NAME` (`NAME`),
  UNIQUE KEY `UUID` (`UUID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `STATE_DAT_SRC`
--

LOCK TABLES `STATE_DAT_SRC` WRITE;
/*!40000 ALTER TABLE `STATE_DAT_SRC` DISABLE KEYS */;
/*!40000 ALTER TABLE `STATE_DAT_SRC` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `STAT_DAT_SRC`
--

DROP TABLE IF EXISTS `STAT_DAT_SRC`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `STAT_DAT_SRC` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `VER` tinyint(4) NOT NULL,
  `CRT_MS` bigint(20) DEFAULT NULL,
  `CRT_USER` varchar(255) DEFAULT NULL,
  `UPD_MS` bigint(20) DEFAULT NULL,
  `UPD_USER` varchar(255) DEFAULT NULL,
  `NAME` varchar(255) NOT NULL,
  `UUID` varchar(255) NOT NULL,
  `DESCRIP` longtext,
  `PRES` bigint(20) NOT NULL,
  `ENBL` bit(1) NOT NULL,
  `STAT_TP` tinyint(4) NOT NULL,
  `ROLLUP_TP` tinyint(4) NOT NULL,
  `DAT` longtext,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `UUID` (`UUID`),
  UNIQUE KEY `NAME` (`NAME`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `STAT_DAT_SRC`
--

LOCK TABLES `STAT_DAT_SRC` WRITE;
/*!40000 ALTER TABLE `STAT_DAT_SRC` DISABLE KEYS */;
/*!40000 ALTER TABLE `STAT_DAT_SRC` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `STRM`
--

DROP TABLE IF EXISTS `STRM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `STRM` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `VER` tinyint(4) NOT NULL,
  `CRT_MS` bigint(20) NOT NULL,
  `EFFECT_MS` bigint(20) DEFAULT NULL,
  `PARNT_STRM_ID` bigint(20) DEFAULT NULL,
  `STAT` tinyint(4) NOT NULL,
  `STAT_MS` bigint(20) DEFAULT NULL,
  `STRM_TASK_ID` bigint(20) DEFAULT NULL,
  `FK_FD_ID` int(11) NOT NULL,
  `FK_STRM_PROC_ID` int(11) DEFAULT NULL,
  `FK_STRM_TP_ID` int(11) NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `STRM_FK_STRM_TP_ID` (`FK_STRM_TP_ID`),
  KEY `STRM_CRT_MS_IDX` (`CRT_MS`),
  KEY `STRM_FK_FD_ID_CRT_MS_IDX` (`FK_FD_ID`,`CRT_MS`),
  KEY `STRM_FK_STRM_PROC_ID_CRT_MS_IDX` (`FK_STRM_PROC_ID`,`CRT_MS`),
  KEY `STRM_FK_FD_ID_EFFECT_MS_IDX` (`FK_FD_ID`,`EFFECT_MS`),
  KEY `STRM_PARNT_STRM_ID_IDX` (`PARNT_STRM_ID`),
  KEY `STRM_STAT_IDX` (`STAT`),
  CONSTRAINT `STRM_FK_FD_ID` FOREIGN KEY (`FK_FD_ID`) REFERENCES `FD` (`ID`),
  CONSTRAINT `STRM_FK_STRM_PROC_ID` FOREIGN KEY (`FK_STRM_PROC_ID`) REFERENCES `STRM_PROC` (`ID`),
  CONSTRAINT `STRM_FK_STRM_TP_ID` FOREIGN KEY (`FK_STRM_TP_ID`) REFERENCES `STRM_TP` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `STRM`
--

LOCK TABLES `STRM` WRITE;
/*!40000 ALTER TABLE `STRM` DISABLE KEYS */;
/*!40000 ALTER TABLE `STRM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `STRM_ATR_KEY`
--

DROP TABLE IF EXISTS `STRM_ATR_KEY`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `STRM_ATR_KEY` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `VER` tinyint(4) NOT NULL,
  `CRT_USER` varchar(255) DEFAULT NULL,
  `UPD_USER` varchar(255) DEFAULT NULL,
  `NAME` varchar(255) NOT NULL,
  `FLD_TP` tinyint(4) NOT NULL,
  `CRT_MS` bigint(20) DEFAULT NULL,
  `UPD_MS` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `NAME` (`NAME`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `STRM_ATR_KEY`
--

LOCK TABLES `STRM_ATR_KEY` WRITE;
/*!40000 ALTER TABLE `STRM_ATR_KEY` DISABLE KEYS */;
INSERT INTO `STRM_ATR_KEY` VALUES (1,1,'upgrade','upgrade','RecRead',5,1577404800000,1577404800000),(2,1,'upgrade','upgrade','RecWrite',5,1577404800000,1577404800000),(3,1,'upgrade','upgrade','RecError',5,1577404800000,1577404800000),(4,1,'upgrade','upgrade','RecWarn',5,1577404800000,1577404800000),(5,1,'upgrade','upgrade','Node',1,1577404800000,1577404800000),(6,1,'upgrade','upgrade','Feed',1,1577404800000,1577404800000),(7,1,'upgrade','upgrade','StreamId',4,1577404800000,1577404800000),(8,1,'upgrade','upgrade','ParentStreamId',4,1577404800000,1577404800000),(9,1,'upgrade','upgrade','FileSize',6,1577404800000,1577404800000),(10,1,'upgrade','upgrade','StreamSize',6,1577404800000,1577404800000),(11,1,'upgrade','upgrade','StreamType',1,1577404800000,1577404800000),(12,1,'upgrade','upgrade','Duration',7,1577404800000,1577404800000),(13,1,'upgrade','upgrade','CreateTime',3,1577404800000,1577404800000),(14,1,'upgrade','upgrade','EffectiveTime',3,1577404800000,1577404800000),(15,1,'upgrade','upgrade','RecInfo',5,1577404800000,1577404800000),(16,1,'upgrade','upgrade','RecFatal',5,1577404800000,1577404800000);
/*!40000 ALTER TABLE `STRM_ATR_KEY` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `STRM_ATR_VAL`
--

DROP TABLE IF EXISTS `STRM_ATR_VAL`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `STRM_ATR_VAL` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `VER` tinyint(4) NOT NULL,
  `CRT_MS` bigint(20) NOT NULL,
  `VAL_STR` varchar(255) DEFAULT NULL,
  `VAL_NUM` bigint(20) DEFAULT NULL,
  `STRM_ID` bigint(20) NOT NULL,
  `STRM_ATR_KEY_ID` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `STRM_ATR_VAL_STRM_ID_IDX` (`STRM_ID`),
  KEY `STRM_ATR_VAL_CRT_MS_IDX` (`CRT_MS`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `STRM_ATR_VAL`
--

LOCK TABLES `STRM_ATR_VAL` WRITE;
/*!40000 ALTER TABLE `STRM_ATR_VAL` DISABLE KEYS */;
/*!40000 ALTER TABLE `STRM_ATR_VAL` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `STRM_PROC`
--

DROP TABLE IF EXISTS `STRM_PROC`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `STRM_PROC` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `VER` tinyint(4) NOT NULL,
  `CRT_USER` varchar(255) DEFAULT NULL,
  `UPD_USER` varchar(255) DEFAULT NULL,
  `TASK_TP` varchar(255) DEFAULT NULL,
  `FK_PIPE_ID` int(11) DEFAULT NULL,
  `ENBL` bit(1) NOT NULL,
  `CRT_MS` bigint(20) DEFAULT NULL,
  `UPD_MS` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `STRM_PROC_FK_PIPE_ID` (`FK_PIPE_ID`),
  CONSTRAINT `STRM_PROC_FK_PIPE_ID` FOREIGN KEY (`FK_PIPE_ID`) REFERENCES `PIPE` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `STRM_PROC`
--

LOCK TABLES `STRM_PROC` WRITE;
/*!40000 ALTER TABLE `STRM_PROC` DISABLE KEYS */;
/*!40000 ALTER TABLE `STRM_PROC` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `STRM_PROC_FILT`
--

DROP TABLE IF EXISTS `STRM_PROC_FILT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `STRM_PROC_FILT` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `VER` tinyint(4) NOT NULL,
  `CRT_MS` bigint(20) DEFAULT NULL,
  `CRT_USER` varchar(255) DEFAULT NULL,
  `UPD_MS` bigint(20) DEFAULT NULL,
  `UPD_USER` varchar(255) DEFAULT NULL,
  `DAT` longtext NOT NULL,
  `PRIOR` int(11) NOT NULL,
  `FK_STRM_PROC_ID` int(11) NOT NULL,
  `FK_STRM_PROC_FILT_TRAC_ID` int(11) NOT NULL,
  `ENBL` bit(1) NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `STRM_PROC_FILT_FK_STRM_PROC_ID` (`FK_STRM_PROC_ID`),
  KEY `STRM_PROC_FILT_FK_STRM_PROC_FILT_TRAC_ID` (`FK_STRM_PROC_FILT_TRAC_ID`),
  CONSTRAINT `STRM_PROC_FILT_FK_STRM_PROC_FILT_TRAC_ID` FOREIGN KEY (`FK_STRM_PROC_FILT_TRAC_ID`) REFERENCES `STRM_PROC_FILT_TRAC` (`ID`),
  CONSTRAINT `STRM_PROC_FILT_FK_STRM_PROC_ID` FOREIGN KEY (`FK_STRM_PROC_ID`) REFERENCES `STRM_PROC` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `STRM_PROC_FILT`
--

LOCK TABLES `STRM_PROC_FILT` WRITE;
/*!40000 ALTER TABLE `STRM_PROC_FILT` DISABLE KEYS */;
/*!40000 ALTER TABLE `STRM_PROC_FILT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `STRM_PROC_FILT_TRAC`
--

DROP TABLE IF EXISTS `STRM_PROC_FILT_TRAC`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `STRM_PROC_FILT_TRAC` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `VER` tinyint(4) NOT NULL,
  `MIN_STRM_ID` bigint(20) NOT NULL,
  `MIN_EVT_ID` bigint(20) NOT NULL,
  `MIN_STRM_CRT_MS` bigint(20) DEFAULT NULL,
  `MAX_STRM_CRT_MS` bigint(20) DEFAULT NULL,
  `STRM_CRT_MS` bigint(20) DEFAULT NULL,
  `LAST_POLL_MS` bigint(20) DEFAULT NULL,
  `LAST_POLL_TASK_CT` int(11) DEFAULT NULL,
  `STAT` varchar(255) DEFAULT NULL,
  `STRM_CT` bigint(20) DEFAULT NULL,
  `EVT_CT` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `STRM_PROC_FILT_TRAC`
--

LOCK TABLES `STRM_PROC_FILT_TRAC` WRITE;
/*!40000 ALTER TABLE `STRM_PROC_FILT_TRAC` DISABLE KEYS */;
/*!40000 ALTER TABLE `STRM_PROC_FILT_TRAC` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `STRM_TASK`
--

DROP TABLE IF EXISTS `STRM_TASK`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `STRM_TASK` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `VER` tinyint(4) NOT NULL,
  `CRT_MS` bigint(20) DEFAULT NULL,
  `END_TIME_MS` bigint(20) DEFAULT NULL,
  `STAT` tinyint(4) NOT NULL,
  `STAT_MS` bigint(20) DEFAULT NULL,
  `START_TIME_MS` bigint(20) DEFAULT NULL,
  `FK_ND_ID` int(11) DEFAULT NULL,
  `FK_STRM_ID` bigint(20) NOT NULL,
  `DAT` longtext,
  `FK_STRM_PROC_FILT_ID` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `STRM_TASK_FK_ND_ID` (`FK_ND_ID`),
  KEY `STRM_TASK_STAT_IDX` (`STAT`),
  KEY `STRM_TASK_FK_STRM_ID` (`FK_STRM_ID`),
  KEY `STRM_TASK_FK_STRM_PROC_FILT_ID` (`FK_STRM_PROC_FILT_ID`),
  CONSTRAINT `STRM_TASK_FK_ND_ID` FOREIGN KEY (`FK_ND_ID`) REFERENCES `ND` (`ID`),
  CONSTRAINT `STRM_TASK_FK_STRM_PROC_FILT_ID` FOREIGN KEY (`FK_STRM_PROC_FILT_ID`) REFERENCES `STRM_PROC_FILT` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `STRM_TASK`
--

LOCK TABLES `STRM_TASK` WRITE;
/*!40000 ALTER TABLE `STRM_TASK` DISABLE KEYS */;
/*!40000 ALTER TABLE `STRM_TASK` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `STRM_TP`
--

DROP TABLE IF EXISTS `STRM_TP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `STRM_TP` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `VER` tinyint(4) NOT NULL,
  `CRT_USER` varchar(255) DEFAULT NULL,
  `UPD_USER` varchar(255) DEFAULT NULL,
  `NAME` varchar(255) NOT NULL,
  `EXT` varchar(255) NOT NULL,
  `PURP` tinyint(4) NOT NULL,
  `PATH` varchar(255) NOT NULL,
  `CRT_MS` bigint(20) DEFAULT NULL,
  `UPD_MS` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `NAME` (`NAME`)
) ENGINE=InnoDB AUTO_INCREMENT=72 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `STRM_TP`
--

LOCK TABLES `STRM_TP` WRITE;
/*!40000 ALTER TABLE `STRM_TP` DISABLE KEYS */;
INSERT INTO `STRM_TP` VALUES (1,1,'upgrade','upgrade','Manifest','mf',0,'MANIFEST',1577451708441,1577451708441),(11,1,'upgrade','upgrade','Raw Events','revt',10,'RAW_EVENTS',1577451708441,1577451708441),(12,1,'upgrade','upgrade','Raw Reference','rref',10,'RAW_REFERENCE',1577451708441,1577451708441),(21,1,'upgrade','upgrade','Events','evt',11,'EVENTS',1577451708441,1577451708441),(22,1,'upgrade','upgrade','Reference','ref',11,'REFERENCE',1577451708441,1577451708441),(31,1,'upgrade','upgrade','Segment Index','seg',1,'SEGMENT_INDEX',1577451708441,1577451708441),(32,1,'upgrade','upgrade','Boundary Index','bdy',1,'BOUNDARY_INDEX',1577451708441,1577451708441),(33,1,'upgrade','upgrade','Meta Data','meta',0,'META',1577451708441,1577451708441),(34,1,'upgrade','upgrade','Context','ctx',2,'CONTEXT',1577451708441,1577451708441),(35,1,'upgrade','upgrade','Error','err',50,'ERROR',1577451708441,1577451708441),(51,1,'upgrade','upgrade','Test Events','tevt',11,'TEST_EVENTS',1577451708441,1577451708441),(52,1,'upgrade','upgrade','Test Reference','tref',11,'TEST_REFERENCE',1577451708441,1577451708441),(71,1,'upgrade','upgrade','Records','rec',11,'RECORDS',1577451708441,1577451708441);
/*!40000 ALTER TABLE `STRM_TP` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `STRM_VOL`
--

DROP TABLE IF EXISTS `STRM_VOL`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `STRM_VOL` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `VER` tinyint(4) NOT NULL,
  `FK_STRM_ID` bigint(20) NOT NULL,
  `FK_VOL_ID` int(11) NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `STRM_VOL_FK_VOL_ID` (`FK_VOL_ID`),
  KEY `STRM_VOL_FK_STRM_ID` (`FK_STRM_ID`),
  CONSTRAINT `STRM_VOL_FK_STRM_ID` FOREIGN KEY (`FK_STRM_ID`) REFERENCES `STRM` (`ID`),
  CONSTRAINT `STRM_VOL_FK_VOL_ID` FOREIGN KEY (`FK_VOL_ID`) REFERENCES `VOL` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `STRM_VOL`
--

LOCK TABLES `STRM_VOL` WRITE;
/*!40000 ALTER TABLE `STRM_VOL` DISABLE KEYS */;
/*!40000 ALTER TABLE `STRM_VOL` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `STROOM_STATS_STORE`
--

DROP TABLE IF EXISTS `STROOM_STATS_STORE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `STROOM_STATS_STORE` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `VER` tinyint(4) NOT NULL,
  `CRT_MS` bigint(20) DEFAULT NULL,
  `CRT_USER` varchar(255) DEFAULT NULL,
  `UPD_MS` bigint(20) DEFAULT NULL,
  `UPD_USER` varchar(255) DEFAULT NULL,
  `NAME` varchar(255) NOT NULL,
  `UUID` varchar(255) NOT NULL,
  `DESCRIP` longtext,
  `PRES` varchar(255) NOT NULL,
  `ENBL` bit(1) NOT NULL,
  `STAT_TP` tinyint(4) NOT NULL,
  `ROLLUP_TP` tinyint(4) NOT NULL,
  `DAT` longtext,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `NAME` (`NAME`),
  UNIQUE KEY `UUID` (`UUID`),
  KEY `STROOM_STATS_STORE_NAME_IDX` (`NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `STROOM_STATS_STORE`
--

LOCK TABLES `STROOM_STATS_STORE` WRITE;
/*!40000 ALTER TABLE `STROOM_STATS_STORE` DISABLE KEYS */;
/*!40000 ALTER TABLE `STROOM_STATS_STORE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TXT_CONV`
--

DROP TABLE IF EXISTS `TXT_CONV`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `TXT_CONV` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `VER` tinyint(4) NOT NULL,
  `CRT_MS` bigint(20) DEFAULT NULL,
  `CRT_USER` varchar(255) DEFAULT NULL,
  `UPD_MS` bigint(20) DEFAULT NULL,
  `UPD_USER` varchar(255) DEFAULT NULL,
  `NAME` varchar(255) NOT NULL,
  `UUID` varchar(255) NOT NULL,
  `DESCRIP` longtext,
  `CONV_TP` tinyint(4) NOT NULL,
  `DAT` longtext,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `UUID` (`UUID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TXT_CONV`
--

LOCK TABLES `TXT_CONV` WRITE;
/*!40000 ALTER TABLE `TXT_CONV` DISABLE KEYS */;
/*!40000 ALTER TABLE `TXT_CONV` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `USR`
--

DROP TABLE IF EXISTS `USR`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `USR` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `VER` tinyint(4) NOT NULL,
  `CRT_MS` bigint(20) DEFAULT NULL,
  `CRT_USER` varchar(255) DEFAULT NULL,
  `UPD_MS` bigint(20) DEFAULT NULL,
  `UPD_USER` varchar(255) DEFAULT NULL,
  `NAME` varchar(255) NOT NULL,
  `UUID` varchar(255) NOT NULL,
  `GRP` bit(1) NOT NULL,
  `STAT` tinyint(4) NOT NULL,
  `CUR_LOGIN_FAIL` smallint(6) NOT NULL,
  `LOGIN_EXPIRY` bit(1) NOT NULL,
  `LAST_LOGIN_MS` bigint(20) DEFAULT NULL,
  `LOGIN_VALID_MS` bigint(20) DEFAULT NULL,
  `PASS_EXPIRY_MS` bigint(20) DEFAULT NULL,
  `PASS_HASH` varchar(255) DEFAULT NULL,
  `TOTL_LOGIN_FAIL` smallint(6) NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `NAME` (`NAME`,`GRP`),
  UNIQUE KEY `USR_UUID_IDX` (`UUID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `USR`
--

LOCK TABLES `USR` WRITE;
/*!40000 ALTER TABLE `USR` DISABLE KEYS */;
INSERT INTO `USR` VALUES (1,0,1577451710341,'INTERNAL',1577451710341,'INTERNAL','admin','70f71ac9-c239-4825-8426-43d6f6f95c63','\0',0,0,'',NULL,NULL,NULL,NULL,0),(2,0,1577451710358,'INTERNAL',1577451710358,'INTERNAL','Administrators','2d6b03f6-7108-417d-9daf-4f8bbcf3f5b5','',0,0,'',NULL,NULL,NULL,NULL,0),(3,0,1577451710387,'INTERNAL',1577451710387,'INTERNAL','stroomServiceUser','1ee7ec70-7537-4518-94c4-7b37dd48a695','\0',0,0,'',NULL,NULL,NULL,NULL,0),(4,0,1577451722658,'INTERNAL',1577451722658,'INTERNAL','INTERNAL','40e31b9e-0fd7-4018-b02a-a7d9d5b85185','\0',0,0,'',NULL,NULL,NULL,NULL,0);
/*!40000 ALTER TABLE `USR` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `USR_GRP_USR`
--

DROP TABLE IF EXISTS `USR_GRP_USR`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `USR_GRP_USR` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `VER` tinyint(4) NOT NULL,
  `GRP_UUID` varchar(255) NOT NULL,
  `USR_UUID` varchar(255) NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `USR_GRP_USR_GRP_UUID_USR_UUID_IDX` (`GRP_UUID`,`USR_UUID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `USR_GRP_USR`
--

LOCK TABLES `USR_GRP_USR` WRITE;
/*!40000 ALTER TABLE `USR_GRP_USR` DISABLE KEYS */;
INSERT INTO `USR_GRP_USR` VALUES (1,1,'2d6b03f6-7108-417d-9daf-4f8bbcf3f5b5','70f71ac9-c239-4825-8426-43d6f6f95c63'),(2,1,'2d6b03f6-7108-417d-9daf-4f8bbcf3f5b5','1ee7ec70-7537-4518-94c4-7b37dd48a695');
/*!40000 ALTER TABLE `USR_GRP_USR` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `VIS`
--

DROP TABLE IF EXISTS `VIS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `VIS` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `VER` tinyint(4) NOT NULL,
  `CRT_MS` bigint(20) DEFAULT NULL,
  `CRT_USER` varchar(255) DEFAULT NULL,
  `UPD_MS` bigint(20) DEFAULT NULL,
  `UPD_USER` varchar(255) DEFAULT NULL,
  `NAME` varchar(255) NOT NULL,
  `UUID` varchar(255) DEFAULT NULL,
  `DESCRIP` longtext,
  `FUNC_NAME` varchar(255) DEFAULT NULL,
  `SCRIPT` longtext,
  `SETTINGS` longtext,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `UUID` (`UUID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `VIS`
--

LOCK TABLES `VIS` WRITE;
/*!40000 ALTER TABLE `VIS` DISABLE KEYS */;
/*!40000 ALTER TABLE `VIS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `VOL`
--

DROP TABLE IF EXISTS `VOL`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `VOL` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `VER` tinyint(4) NOT NULL,
  `CRT_USER` varchar(255) DEFAULT NULL,
  `UPD_USER` varchar(255) DEFAULT NULL,
  `PATH` varchar(255) NOT NULL,
  `IDX_STAT` tinyint(4) NOT NULL,
  `STRM_STAT` tinyint(4) NOT NULL,
  `VOL_TP` tinyint(4) NOT NULL,
  `BYTES_LMT` bigint(20) DEFAULT NULL,
  `FK_ND_ID` int(11) NOT NULL,
  `FK_VOL_STATE_ID` int(11) NOT NULL,
  `CRT_MS` bigint(20) DEFAULT NULL,
  `UPD_MS` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `FK_ND_ID` (`FK_ND_ID`,`PATH`),
  KEY `VOL_STAT_FK_VOL_STATE_ID` (`FK_VOL_STATE_ID`),
  CONSTRAINT `VOL_FK_ND_ID` FOREIGN KEY (`FK_ND_ID`) REFERENCES `ND` (`ID`),
  CONSTRAINT `VOL_STAT_FK_VOL_STATE_ID` FOREIGN KEY (`FK_VOL_STATE_ID`) REFERENCES `VOL_STATE` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `VOL`
--

LOCK TABLES `VOL` WRITE;
/*!40000 ALTER TABLE `VOL` DISABLE KEYS */;
INSERT INTO `VOL` VALUES (1,0,'INTERNAL','INTERNAL','/stroom/volumes/defaultIndexVolume',0,1,1,70864780492,1,1,1577451711667,1577451711667),(2,0,'INTERNAL','INTERNAL','/stroom/volumes/defaultStreamVolume',1,0,0,70864780492,1,2,1577451711688,1577451711688);
/*!40000 ALTER TABLE `VOL` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `VOL_STATE`
--

DROP TABLE IF EXISTS `VOL_STATE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `VOL_STATE` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `VER` tinyint(4) NOT NULL,
  `BYTES_USED` bigint(20) DEFAULT NULL,
  `BYTES_FREE` bigint(20) DEFAULT NULL,
  `BYTES_TOTL` bigint(20) DEFAULT NULL,
  `STAT_MS` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `VOL_STATE`
--

LOCK TABLES `VOL_STATE` WRITE;
/*!40000 ALTER TABLE `VOL_STATE` DISABLE KEYS */;
INSERT INTO `VOL_STATE` VALUES (1,0,NULL,NULL,NULL,NULL),(2,0,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `VOL_STATE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `XML_SCHEMA`
--

DROP TABLE IF EXISTS `XML_SCHEMA`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `XML_SCHEMA` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `VER` tinyint(4) NOT NULL,
  `CRT_MS` bigint(20) DEFAULT NULL,
  `CRT_USER` varchar(255) DEFAULT NULL,
  `UPD_MS` bigint(20) DEFAULT NULL,
  `UPD_USER` varchar(255) DEFAULT NULL,
  `NAME` varchar(255) NOT NULL,
  `UUID` varchar(255) NOT NULL,
  `DESCRIP` longtext,
  `DAT` longtext,
  `DEPRC` bit(1) NOT NULL,
  `SCHEMA_GRP` varchar(255) DEFAULT NULL,
  `NS` varchar(255) DEFAULT NULL,
  `SYSTEM_ID` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `UUID` (`UUID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `XML_SCHEMA`
--

LOCK TABLES `XML_SCHEMA` WRITE;
/*!40000 ALTER TABLE `XML_SCHEMA` DISABLE KEYS */;
/*!40000 ALTER TABLE `XML_SCHEMA` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `XSLT`
--

DROP TABLE IF EXISTS `XSLT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `XSLT` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `VER` tinyint(4) NOT NULL,
  `CRT_MS` bigint(20) DEFAULT NULL,
  `CRT_USER` varchar(255) DEFAULT NULL,
  `UPD_MS` bigint(20) DEFAULT NULL,
  `UPD_USER` varchar(255) DEFAULT NULL,
  `NAME` varchar(255) NOT NULL,
  `UUID` varchar(255) NOT NULL,
  `DESCRIP` longtext,
  `DAT` longtext,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `UUID` (`UUID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `XSLT`
--

LOCK TABLES `XSLT` WRITE;
/*!40000 ALTER TABLE `XSLT` DISABLE KEYS */;
/*!40000 ALTER TABLE `XSLT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `doc`
--

DROP TABLE IF EXISTS `doc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `doc` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `uuid` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `data` longtext,
  PRIMARY KEY (`id`),
  UNIQUE KEY `type` (`type`,`uuid`),
  KEY `doc_type_uuid_idx` (`type`,`uuid`),
  KEY `doc_uuid_idx` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `doc`
--

LOCK TABLES `doc` WRITE;
/*!40000 ALTER TABLE `doc` DISABLE KEYS */;
/*!40000 ALTER TABLE `doc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `explorerTreeNode`
--

DROP TABLE IF EXISTS `explorerTreeNode`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `explorerTreeNode` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `uuid` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `tags` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `type` (`type`,`uuid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `explorerTreeNode`
--

LOCK TABLES `explorerTreeNode` WRITE;
/*!40000 ALTER TABLE `explorerTreeNode` DISABLE KEYS */;
INSERT INTO `explorerTreeNode` VALUES (1,'System','0','System',NULL);
/*!40000 ALTER TABLE `explorerTreeNode` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `explorerTreePath`
--

DROP TABLE IF EXISTS `explorerTreePath`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `explorerTreePath` (
  `ancestor` int(11) NOT NULL,
  `descendant` int(11) NOT NULL,
  `depth` int(11) NOT NULL,
  `orderIndex` int(11) NOT NULL,
  PRIMARY KEY (`ancestor`,`descendant`),
  KEY `explorerTreePath_descendant_depth_idx` (`descendant`,`depth`),
  KEY `explorerTreePath_ancestor_depth_orderIndex_idx` (`ancestor`,`depth`,`orderIndex`),
  KEY `explorerTreePath_depth_idx` (`depth`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `explorerTreePath`
--

LOCK TABLES `explorerTreePath` WRITE;
/*!40000 ALTER TABLE `explorerTreePath` DISABLE KEYS */;
INSERT INTO `explorerTreePath` VALUES (1,1,0,-1);
/*!40000 ALTER TABLE `explorerTreePath` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schema_version`
--

DROP TABLE IF EXISTS `schema_version`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `schema_version` (
  `installed_rank` int(11) NOT NULL,
  `version` varchar(50) DEFAULT NULL,
  `description` varchar(200) NOT NULL,
  `type` varchar(20) NOT NULL,
  `script` varchar(1000) NOT NULL,
  `checksum` int(11) DEFAULT NULL,
  `installed_by` varchar(100) NOT NULL,
  `installed_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `execution_time` int(11) NOT NULL,
  `success` tinyint(1) NOT NULL,
  PRIMARY KEY (`installed_rank`),
  KEY `schema_version_s_idx` (`success`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schema_version`
--

LOCK TABLES `schema_version` WRITE;
/*!40000 ALTER TABLE `schema_version` DISABLE KEYS */;
INSERT INTO `schema_version` VALUES (1,'4.0.60','Schema','SQL','V4_0_60__Schema.sql',-2101129985,'stroomuser','2019-12-27 13:01:12',3372,1),(2,'5.0.0.0','Drop Old Tables','SQL','V5_0_0_0__Drop_Old_Tables.sql',-832207379,'stroomuser','2019-12-27 13:01:12',116,1),(3,'5.0.0.1','CRT MS','JDBC','stroom.db.migration.mysql.V5_0_0_1__CRT_MS',NULL,'stroomuser','2019-12-27 13:01:21',8525,1),(4,'5.0.0.2','Folders','SQL','V5_0_0_2__Folders.sql',1557457318,'stroomuser','2019-12-27 13:01:24',3023,1),(5,'5.0.0.3','Add UUID','SQL','V5_0_0_3__Add_UUID.sql',1319162908,'stroomuser','2019-12-27 13:01:27',2873,1),(6,'5.0.0.4','XMLSchema','SQL','V5_0_0_4__XMLSchema.sql',172131384,'stroomuser','2019-12-27 13:01:27',21,1),(7,'5.0.0.5','Analytic Output','SQL','V5_0_0_5__Analytic_Output.sql',1136436681,'stroomuser','2019-12-27 13:01:27',44,1),(8,'5.0.0.6','State Data Source','SQL','V5_0_0_6__State_Data_Source.sql',-1511421222,'stroomuser','2019-12-27 13:01:27',50,1),(9,'5.0.0.10','Pipeline','JDBC','stroom.db.migration.mysql.V5_0_0_10__Pipeline',NULL,'stroomuser','2019-12-27 13:01:27',180,1),(10,'5.0.0.11','Visualisations','JDBC','stroom.db.migration.mysql.V5_0_0_11__Visualisations',NULL,'stroomuser','2019-12-27 13:01:27',183,1),(11,'5.0.0.12','Script','JDBC','stroom.db.migration.mysql.V5_0_0_12__Script',NULL,'stroomuser','2019-12-27 13:01:27',124,1),(12,'5.0.0.13','Dashboards','JDBC','stroom.db.migration.mysql.V5_0_0_13__Dashboards',NULL,'stroomuser','2019-12-27 13:01:27',2,1),(13,'5.0.0.20','UTF8 Tables','SQL','V5_0_0_20__UTF8_Tables.sql',1277143417,'stroomuser','2019-12-27 13:01:30',2186,1),(14,'5.0.0.40','Security','SQL','V5_0_0_40__Security.sql',-1039800148,'stroomuser','2019-12-27 13:01:30',389,1),(15,'5.0.0.41','Drop Internal Statistics','SQL','V5_0_0_41__Drop_Internal_Statistics.sql',-83041294,'stroomuser','2019-12-27 13:01:30',14,1),(16,'5.0.0.42','Query','SQL','V5_0_0_42__Query.sql',367730772,'stroomuser','2019-12-27 13:01:30',217,1),(17,'5.0.0.43','FolderIdSet','JDBC','stroom.db.migration.mysql.V5_0_0_43__FolderIdSet',NULL,'stroomuser','2019-12-27 13:01:30',3,1),(18,'5.0.0.44','PipelineProperties','JDBC','stroom.db.migration.mysql.V5_0_0_44__PipelineProperties',NULL,'stroomuser','2019-12-27 13:01:30',2,1),(19,'5.0.0.52','Drop Old Int Stat Folders','SQL','V5_0_0_52__Drop_Old_Int_Stat_Folders.sql',570470073,'stroomuser','2019-12-27 13:01:30',20,1),(20,'5.1.0.0','Policy','SQL','V5_1_0_0__Policy.sql',-1896264422,'stroomuser','2019-12-27 13:01:30',46,1),(21,'5.5.0.0','Activity','SQL','V5_5_0_0__Activity.sql',-1699498621,'stroomuser','2019-12-27 13:01:30',50,1),(22,'5.5.0.1','PipelineProperties','JDBC','stroom.db.migration.mysql.V5_5_0_1__PipelineProperties',NULL,'stroomuser','2019-12-27 13:01:31',2,1),(23,'6.0.0.0','Stroom Stats store','SQL','V6_0_0_0__Stroom_Stats_store.sql',933182208,'stroomuser','2019-12-27 13:01:31',87,1),(24,'6.0.0.1','Drop STAT DAT SRC ENGINE NAME','SQL','V6_0_0_1__Drop_STAT_DAT_SRC_ENGINE_NAME.sql',166011846,'stroomuser','2019-12-27 13:01:31',171,1),(25,'6.0.0.2','Rename stroom.search.maxResults','SQL','V6_0_0_2__Rename_stroom.search.maxResults.sql',-1478484124,'stroomuser','2019-12-27 13:01:31',4,1),(26,'6.0.0.3','Fix Feed Stream Type','SQL','V6_0_0_3__Fix_Feed_Stream_Type.sql',-437961708,'stroomuser','2019-12-27 13:01:31',5,1),(27,'6.0.0.9','ProcessingFilter','JDBC','stroom.db.migration.mysql.V6_0_0_9__ProcessingFilter',NULL,'stroomuser','2019-12-27 13:01:31',3,1),(28,'6.0.0.10','Explorer','SQL','V6_0_0_10__Explorer.sql',-234044802,'stroomuser','2019-12-27 13:01:31',92,1),(29,'6.0.0.11','Explorer','JDBC','stroom.db.migration.mysql.V6_0_0_11__Explorer',NULL,'stroomuser','2019-12-27 13:01:31',16,1),(30,'6.0.0.12','Explorer','SQL','V6_0_0_12__Explorer.sql',-909849265,'stroomuser','2019-12-27 13:01:33',1503,1),(31,'6.0.0.20','Doc','SQL','V6_0_0_20__Doc.sql',1732771993,'stroomuser','2019-12-27 13:01:33',118,1),(32,'6.0.0.21','Dictionary','JDBC','stroom.db.migration.mysql.V6_0_0_21__Dictionary',NULL,'stroomuser','2019-12-27 13:01:33',3,1),(33,'6.0.0.30','Script','SQL','V6_0_0_30__Script.sql',1497691621,'stroomuser','2019-12-27 13:01:33',141,1),(34,'6.0.0.31','Res','SQL','V6_0_0_31__Res.sql',1236448013,'stroomuser','2019-12-27 13:01:33',17,1),(35,'6.0.0.32','Rename old NStatFilter references','SQL','V6_0_0_32__Rename_old_NStatFilter_references.sql',-855772922,'stroomuser','2019-12-27 13:01:33',4,1),(36,'6.0.0.33','Rename old Stream Type references','SQL','V6_0_0_33__Rename_old_Stream_Type_references.sql',-544410736,'stroomuser','2019-12-27 13:01:33',2,1),(37,'6.0.0.34','Change processor field names','SQL','V6_0_0_34__Change_processor_field_names.sql',-1259328219,'stroomuser','2019-12-27 13:01:33',8,1),(38,'6.0.0.35','Change processor field names again','SQL','V6_0_0_35__Change_processor_field_names_again.sql',1169459378,'stroomuser','2019-12-27 13:01:33',2,1),(39,'6.0.0.36','Remove jmapexecutable prop','SQL','V6_0_0_36__Remove_jmapexecutable_prop.sql',-1498100147,'stroomuser','2019-12-27 13:01:33',2,1),(40,'6.0.0.37','Change data retention field names','SQL','V6_0_0_37__Change_data_retention_field_names.sql',-2111551039,'stroomuser','2019-12-27 13:01:33',3,1),(41,'6.0.0.40','Explorer indexes','SQL','V6_0_0_40__Explorer_indexes.sql',337767213,'stroomuser','2019-12-27 13:01:33',152,1),(42,'6.0.0.41','Change dictionary to docref','SQL','V6_0_0_41__Change_dictionary_to_docref.sql',1165505631,'stroomuser','2019-12-27 13:01:33',30,1),(43,'6.0.0.42','Explorer indexes','SQL','V6_0_0_42__Explorer_indexes.sql',1160286997,'stroomuser','2019-12-27 13:01:33',20,1),(44,'6.0.0.43','Doc Perm indexes','SQL','V6_0_0_43__Doc_Perm_indexes.sql',438015179,'stroomuser','2019-12-27 13:01:33',33,1);
/*!40000 ALTER TABLE `schema_version` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-12-27 13:02:16
