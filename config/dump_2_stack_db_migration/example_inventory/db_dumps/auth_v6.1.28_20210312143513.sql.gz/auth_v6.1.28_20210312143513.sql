-- MySQL dump 10.13  Distrib 5.6.47, for Linux (x86_64)
--
-- Host: localhost    Database: auth
-- ------------------------------------------------------
-- Server version	5.6.47

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `OLD_AUTH_json_web_key`
--

DROP TABLE IF EXISTS `OLD_AUTH_json_web_key`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `OLD_AUTH_json_web_key` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `keyId` varchar(255) NOT NULL,
  `json` text NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `keyId` (`keyId`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `OLD_AUTH_json_web_key`
--

LOCK TABLES `OLD_AUTH_json_web_key` WRITE;
/*!40000 ALTER TABLE `OLD_AUTH_json_web_key` DISABLE KEYS */;
INSERT INTO `OLD_AUTH_json_web_key` VALUES (1,'1ec7a983-317d-46ce-ae93-ce42bc217e52','{\"kty\":\"RSA\",\"kid\":\"1ec7a983-317d-46ce-ae93-ce42bc217e52\",\"n\":\"72G4eRyG91OlsKOs-s2vBsbvXV5IKDOUpqDkFKYR_pCJwSBgD4BZYZ_qnIXx5L6cIK1Hsk_nMchHnL9lK7-nIt_bO41AyBes2IF2TTPuPKwqGY-aKCcuRh_BkDrCPZBR7-iyuYigL8MwgiP-yX6ieNpXzrfy3C8IYwLrKjLt39fb0fBod6_nrBPZeBUlH5m5pswNDfbOJII3bEGq5uQw5SZbaGBEEVbvkLNTROByK1PuOezfrpAyTWHCsG-zEsQ0HuIFyVo07sFJhV1AypPL-s71vKi6sDY46Mc5I2KV4CHbdvIhHT4xTaAhE9VimZgQW6sVvpRalV5XL8czjWVjtw\",\"e\":\"AQAB\",\"d\":\"HnwZXAMQBQs3_Ii7jK0I7xoCfad2FPiMo7O1mBOWEw8hG-EdmpvDxjTxUcGVDoZfp6GpkcGvNZ3F0OZm4e1kQYK0jp7scw7gyimigS5t1nguXFb3UMm8kN2WbuGsvt5UMPM3X31QuQRodwpSdiKUWkOkDwVJ_lRXAxTqEdOui2TY2WzKijvBEahyA2pqUGvrajF2GKFbZzXO1zagq6VhGCQohvCkaRWB-tVzc4-Ns6v3jqCKRpYYPrxD4C0RZ1K6InkxtXg1qYrcGMAPzCbqdjLoN41k-ZLNrp8rUSbRf2JAv9A8Ca2r6GDa0PcsySIbUWfduXOgGSuSfW6Hze1nMQ\",\"p\":\"__6DyUpzhXxh6JfRghv2K371tCeV4l1Q45S92Ea1IX3Y6iBweK4W6ToQYTM7l_0bA5eaJ3kywvmpFqzpEcmtsOJOyg_rPQe3GeBDhUJLHqEPDT4t2yc8eQnrFOdWLEYg2nYWLoOkFPS36UBgJtaxIpyj16qidk-DYSEXpeDcqkM\",\"q\":\"72McA2LIVj3hjlt_JsLpMFpcMm7E6knS-YITQUlwIFmVcW5tNQkC871o5x5AJL2Zj7MwxGHEx1WLzwd8B6lGkFP4BTpjCEoo_kXS-6IWyI3p6v7EmIb1O5Av8W37CA3VkPtuM-_dTFGlEW2vF0_ZetvTL49FlRx01Ekt48pvK30\",\"dp\":\"xEAYQ_6hpVn_rVKGORq6lAnWz2_xhgJH-tCS4fUC81QJMSQBVWMRCWeMGxgtvY06Ynycn1pYwgSnzkxsuUhFse8su9eMXdNGWb4FxWlXMXoDkgFzIiloQNqLsBDRjUuN8CzLQImHBtG9FEJX9C5uybwQF0wnFFBMxe-as345bQU\",\"dq\":\"1z03vNue4dw16Dfgdcueu7kjWL08FKRYK7uG8JbFWHDz68-sJZl6rAlMPzJ13hMT9Z7aZFi8A7apRHaoUIMlTTQStzCuRo_Xl_jUISi2b5EaGA8GWVZPPUUBtoR6x90Yf4lypwQu6CYo0yjZ244SL2Nj2Ulq-Q1jBlTeDAjCOEk\",\"qi\":\"a6D1TYa8dgJDqKfZ926SqPxzA3FiJPWAfo8BTyIahZFqqaPAaXEfKUTTCZKmIqsWwNntGcdmDhnNGZ11E2X8MPYkRpnIQj3BywtDzRbPGJ8AFcvy6Zq_vYl874LFrkvGPILe6NxabRCyrFgDKOQ-gIjkL83t0wyS_vVlrGLtCrk\"}');
/*!40000 ALTER TABLE `OLD_AUTH_json_web_key` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `OLD_AUTH_token_types`
--

DROP TABLE IF EXISTS `OLD_AUTH_token_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `OLD_AUTH_token_types` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `token_type` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `OLD_AUTH_token_types`
--

LOCK TABLES `OLD_AUTH_token_types` WRITE;
/*!40000 ALTER TABLE `OLD_AUTH_token_types` DISABLE KEYS */;
INSERT INTO `OLD_AUTH_token_types` VALUES (1,'user'),(2,'api'),(3,'email_reset');
/*!40000 ALTER TABLE `OLD_AUTH_token_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `OLD_AUTH_tokens`
--

DROP TABLE IF EXISTS `OLD_AUTH_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `OLD_AUTH_tokens` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `user_id` mediumint(9) NOT NULL,
  `token_type_id` mediumint(9) NOT NULL,
  `token` varchar(1000) NOT NULL,
  `expires_on` timestamp NULL DEFAULT NULL,
  `comments` varchar(500) DEFAULT NULL,
  `issued_on` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `issued_by_user` mediumint(9) DEFAULT NULL,
  `enabled` bit(1) DEFAULT b'1',
  `updated_on` timestamp NULL DEFAULT NULL,
  `updated_by_user` mediumint(9) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `fk_issued_to` (`user_id`),
  KEY `fk_issued_by_user` (`issued_by_user`),
  KEY `fk_updated_by_user` (`updated_by_user`),
  KEY `fk_token_type_id` (`token_type_id`),
  CONSTRAINT `fk_issued_by_user` FOREIGN KEY (`issued_by_user`) REFERENCES `OLD_AUTH_users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_issued_to` FOREIGN KEY (`user_id`) REFERENCES `OLD_AUTH_users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_token_type_id` FOREIGN KEY (`token_type_id`) REFERENCES `OLD_AUTH_token_types` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_updated_by_user` FOREIGN KEY (`updated_by_user`) REFERENCES `OLD_AUTH_users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `OLD_AUTH_tokens`
--

LOCK TABLES `OLD_AUTH_tokens` WRITE;
/*!40000 ALTER TABLE `OLD_AUTH_tokens` DISABLE KEYS */;
INSERT INTO `OLD_AUTH_tokens` VALUES (3,2,2,'eyJhbGciOiJSUzI1NiJ9.eyJzdWIiOiJhZG1pbiIsImlzcyI6InN0cm9vbSIsInNpZCI6bnVsbH0.k0Ssb43GCdTunAMeM26fIulYKNUuPUaJJk6GxDmzCPb7kVPwEtdfBSrtwazfEFM97dnmvURkLqs-DAZTXhhf-0VqQx4hkwcCHf83eVptWTy-lufIhQo6FCM223c9ONIhl6CPqknWh9Bo3vFNrNJoKz5Zw2T_iCcQhi2WGjd_tjTG7VbibTIpH3lPQDw1IBD2nMsEqACJSk3IaFe0GYcrAEMwsjj3sjAwByMbj5DJvo_DJbAuzUwS5IVpASEENen5Xd3wALLirrraUfED1OY0G56Ttcwl3uQ2s-grZXBM4JCiIurlWR5iNtNwoPUsZsyMju4FMSXt3Ur1NIpD7XKJlg',NULL,NULL,'2021-03-12 14:22:40',2,'',NULL,NULL),(4,3,2,'eyJhbGciOiJSUzI1NiJ9.eyJzdWIiOiJzdGF0c1NlcnZpY2VVc2VyIiwiaXNzIjoic3Ryb29tIiwic2lkIjpudWxsfQ.u2IEhW3Vswpc8ooeYaVQfPTeOA9kzdbnOyZKHDyam-RxDSS90lgRxUvk1SVqb0-jiz3WWpXF8O4zlIIwbJ01-SElpuC5g1roqn4sKDE3N8iGZxINOlku16eEAjT11pbZvlvSr9RdYJS-s118C92z7Xa6gSN_PwBwWRssUchc6NvKNxtBKpcLPbTe3Fp7cesZGiAm-UzqWpPUBv1giXKGfgTXAnpDSzSPSX2f7h8timgRBaxRfMfos7QvfUDaN4IGkcwDyQPFJt4mYdA7aZrVYLfiNwwwaShlsB7o2TqkS4YqvW7aNa90wjrT43hMNsNoKp2S1Upm_nUYF-QGZIF0fQ',NULL,NULL,'2021-03-12 14:22:40',3,'',NULL,NULL);
/*!40000 ALTER TABLE `OLD_AUTH_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `OLD_AUTH_users`
--

DROP TABLE IF EXISTS `OLD_AUTH_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `OLD_AUTH_users` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `password_last_changed` timestamp NULL DEFAULT NULL,
  `state` varchar(10) DEFAULT 'enabled',
  `first_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `comments` text,
  `login_failures` int(11) DEFAULT '0',
  `login_count` int(11) DEFAULT '0',
  `last_login` timestamp NULL DEFAULT NULL,
  `created_on` timestamp NULL DEFAULT NULL,
  `created_by_user` varchar(255) DEFAULT NULL,
  `updated_on` timestamp NULL DEFAULT NULL,
  `updated_by_user` varchar(255) DEFAULT NULL,
  `never_expires` tinyint(1) NOT NULL DEFAULT '0',
  `reactivated_date` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `OLD_AUTH_users`
--

LOCK TABLES `OLD_AUTH_users` WRITE;
/*!40000 ALTER TABLE `OLD_AUTH_users` DISABLE KEYS */;
INSERT INTO `OLD_AUTH_users` VALUES (1,'admin','$2a$10$THzPVeDX70fBaFPjZoY1fOXnCCAezhhYV/LO09w.3JKIybPgRMSiW',NULL,'enabled',NULL,NULL,'Built-in admin user',0,0,NULL,'2021-03-12 14:22:40','Flyway migration',NULL,NULL,1,NULL),(2,'stroomServiceUser','Fake hash: this is a service user and doesn\'t have a password',NULL,'locked',NULL,NULL,'This is a service account and used for associating with an API token not logging in: it\'s locked and must remain so.',0,0,NULL,'2021-03-12 14:22:40','Flyway migration',NULL,NULL,0,NULL),(3,'statsServiceUser','Fake hash: this is a service user and doesn\'t have a password',NULL,'locked',NULL,NULL,'This is a service account and used for associating with an API token not logging in: it\'s locked and must remain so.',0,0,NULL,'2021-03-12 14:22:40','Flyway migration',NULL,NULL,0,NULL),(4,'authenticationResourceUser','Fake hash: this is a service user and doesn\'t have a password',NULL,'locked',NULL,NULL,'This is a service account and used for associating with an API token not logging in: it\'s locked and must remain so.',0,0,NULL,'2021-03-12 14:22:40','Flyway migration',NULL,NULL,0,NULL);
/*!40000 ALTER TABLE `OLD_AUTH_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schema_version`
--

DROP TABLE IF EXISTS `schema_version`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `schema_version` (
  `installed_rank` int(11) NOT NULL,
  `version` varchar(50) DEFAULT NULL,
  `description` varchar(200) NOT NULL,
  `type` varchar(20) NOT NULL,
  `script` varchar(1000) NOT NULL,
  `checksum` int(11) DEFAULT NULL,
  `installed_by` varchar(100) NOT NULL,
  `installed_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `execution_time` int(11) NOT NULL,
  `success` tinyint(1) NOT NULL,
  PRIMARY KEY (`installed_rank`),
  KEY `schema_version_s_idx` (`success`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schema_version`
--

LOCK TABLES `schema_version` WRITE;
/*!40000 ALTER TABLE `schema_version` DISABLE KEYS */;
INSERT INTO `schema_version` VALUES (1,'1','Create tables','SQL','V1__Create_tables.sql',969711635,'authuser','2021-03-12 14:22:40',217,1),(2,'2','Create seed data','SQL','V2__Create_seed_data.sql',-1111189695,'authuser','2021-03-12 14:22:40',37,1),(3,'3','Change JSON type','SQL','V3__Change_JSON_type.sql',-1315140163,'authuser','2021-03-12 14:22:40',100,1),(4,'4','Add Never Expires','SQL','V4__Add_Never_Expires.sql',-663756461,'authuser','2021-03-12 14:22:40',79,1),(5,'5','Update seed data','SQL','V5__Update_seed_data.sql',1373953536,'authuser','2021-03-12 14:22:40',4,1),(6,'6','Add Disabled status','SQL','V6__Add_Disabled_status.sql',-554876788,'authuser','2021-03-12 14:22:40',0,1),(7,'7','Add reactivated date','SQL','V7__Add_reactivated_date.sql',1280534809,'authuser','2021-03-12 14:22:40',70,1),(8,'8','Tidy up seed data','SQL','V8__Tidy_up_seed_data.sql',2025608829,'authuser','2021-03-12 14:22:40',3,1);
/*!40000 ALTER TABLE `schema_version` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-03-12 14:35:13
