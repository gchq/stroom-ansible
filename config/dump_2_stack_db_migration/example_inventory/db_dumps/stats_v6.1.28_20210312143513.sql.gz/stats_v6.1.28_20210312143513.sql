-- MySQL dump 10.13  Distrib 5.6.47, for Linux (x86_64)
--
-- Host: localhost    Database: stats
-- ------------------------------------------------------
-- Server version	5.6.47

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `SQL_STAT_KEY`
--

DROP TABLE IF EXISTS `SQL_STAT_KEY`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SQL_STAT_KEY` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `VER` tinyint(4) NOT NULL,
  `NAME` varchar(766) NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `NAME` (`NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SQL_STAT_KEY`
--

LOCK TABLES `SQL_STAT_KEY` WRITE;
/*!40000 ALTER TABLE `SQL_STAT_KEY` DISABLE KEYS */;
/*!40000 ALTER TABLE `SQL_STAT_KEY` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SQL_STAT_VAL`
--

DROP TABLE IF EXISTS `SQL_STAT_VAL`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SQL_STAT_VAL` (
  `TIME_MS` bigint(20) NOT NULL,
  `PRES` tinyint(4) NOT NULL,
  `VAL_TP` tinyint(4) NOT NULL,
  `VAL` bigint(20) NOT NULL,
  `CT` bigint(20) NOT NULL,
  `FK_SQL_STAT_KEY_ID` bigint(20) NOT NULL,
  PRIMARY KEY (`FK_SQL_STAT_KEY_ID`,`TIME_MS`,`VAL_TP`,`PRES`),
  KEY `SQL_STAT_VAL_TIME_MS` (`TIME_MS`),
  CONSTRAINT `SQL_STAT_VAL_FK_STAT_KEY_ID` FOREIGN KEY (`FK_SQL_STAT_KEY_ID`) REFERENCES `SQL_STAT_KEY` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SQL_STAT_VAL`
--

LOCK TABLES `SQL_STAT_VAL` WRITE;
/*!40000 ALTER TABLE `SQL_STAT_VAL` DISABLE KEYS */;
/*!40000 ALTER TABLE `SQL_STAT_VAL` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SQL_STAT_VAL_SRC`
--

DROP TABLE IF EXISTS `SQL_STAT_VAL_SRC`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SQL_STAT_VAL_SRC` (
  `TIME_MS` bigint(20) NOT NULL,
  `NAME` varchar(766) NOT NULL,
  `VAL_TP` tinyint(4) NOT NULL,
  `VAL` bigint(20) NOT NULL,
  `PROCESSING` bit(1) NOT NULL DEFAULT b'0',
  KEY `SQL_STAT_VAL_SRC_PROCESSING_TIME_MS` (`PROCESSING`,`TIME_MS`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SQL_STAT_VAL_SRC`
--

LOCK TABLES `SQL_STAT_VAL_SRC` WRITE;
/*!40000 ALTER TABLE `SQL_STAT_VAL_SRC` DISABLE KEYS */;
/*!40000 ALTER TABLE `SQL_STAT_VAL_SRC` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `flyway_schema_history`
--

DROP TABLE IF EXISTS `flyway_schema_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `flyway_schema_history` (
  `installed_rank` int(11) NOT NULL,
  `version` varchar(50) DEFAULT NULL,
  `description` varchar(200) NOT NULL,
  `type` varchar(20) NOT NULL,
  `script` varchar(1000) NOT NULL,
  `checksum` int(11) DEFAULT NULL,
  `installed_by` varchar(100) NOT NULL,
  `installed_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `execution_time` int(11) NOT NULL,
  `success` tinyint(1) NOT NULL,
  PRIMARY KEY (`installed_rank`),
  KEY `flyway_schema_history_s_idx` (`success`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flyway_schema_history`
--

LOCK TABLES `flyway_schema_history` WRITE;
/*!40000 ALTER TABLE `flyway_schema_history` DISABLE KEYS */;
INSERT INTO `flyway_schema_history` VALUES (1,'4.0.60','Schema','SQL','V4_0_60__Schema.sql',1214259057,'statsuser','2021-03-12 14:23:28',188,1),(2,NULL,'sql statistics stored procedures','SQL','R__sql_statistics_stored_procedures.sql',-1901382482,'statsuser','2021-03-12 14:23:28',3,1);
/*!40000 ALTER TABLE `flyway_schema_history` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-03-12 14:35:13
